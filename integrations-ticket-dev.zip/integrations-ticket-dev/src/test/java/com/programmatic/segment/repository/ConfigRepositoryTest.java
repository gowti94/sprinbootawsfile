package com.programmatic.segment.repository;

import static org.junit.Assert.assertEquals;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.test.util.ReflectionTestUtils;

import com.programmatic.segment.entity.ConfigEntity;

/**
 * @author wajeeha.k
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ConfigRepositoryTest {

	@Mock
	JdbcTemplate jdbcTemplate;

	@InjectMocks
	ConfigRepository configrepo;

	private List<ConfigEntity> configList = new ArrayList<>();
	private ConfigEntity config;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(configrepo, "jdbcTemplate", jdbcTemplate);
		config = createConfigEntity();
		configList = createConfigList();
		ReflectionTestUtils.setField(configrepo, "dbName", "hive.platformops");
	}

	private List<ConfigEntity> createConfigList() {
		ConfigEntity configEntity1 = new ConfigEntity(1, "ab", 1);
		List<ConfigEntity> list = new ArrayList<>();
		list.add(configEntity1);
		return list;
	}

	private ConfigEntity createConfigEntity() {
		ConfigEntity configEntity = new ConfigEntity(1, "ab", 1);
		return configEntity;
	}

	@Test
	public void getConfigID_test() {
		String SQL_CONFIG_ID_SELECT = "SELECT COALESCE(MAX(config_id), 0) as config_id FROM " + "hive.platformops"
				+ ".segment_config";
		Map<String, Object> map = new HashMap<>();
		map.put("config_id", 1);
		map.put("tag_id", 1);
		map.put("segment_id", 1);
		Mockito.when(jdbcTemplate.queryForMap(SQL_CONFIG_ID_SELECT)).thenReturn(map);
		Integer id = configrepo.getConfigID();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).queryForMap(Mockito.anyString());
		assertEquals(id.longValue(), config.getConfigId().longValue());

	}

	@Test
	public void deleteSegConfig_test() {
		configrepo.deleteSegConfig();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).execute(Mockito.anyString());
	}

	@Test
	public void deleteConfigStg_test() {
		configrepo.deleteConfigStg();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).execute(Mockito.anyString());
	}

	@Test
	public void insertMultipleConfigStg_test() {
		String SQL_INSERT_CONFIG_STG = "INSERT INTO " + "hive.platformops" + ".config_stg "
				+ "(tag_id, segment_id) VALUES(?, ?)" + "";
		ParameterizedPreparedStatementSetter<ConfigEntity> pss = new ParameterizedPreparedStatementSetter<ConfigEntity>() {
			public void setValues(PreparedStatement ps, ConfigEntity configEntity) throws SQLException {
				ps.setString(1, configEntity.getTagId());
				ps.setInt(2, configEntity.getSegmentId());
			}
		};
		int[][] value = new int[3][3];
		value[0][0] = 1;
		value[1][0] = 1;
		Mockito.when(jdbcTemplate.batchUpdate(SQL_INSERT_CONFIG_STG, configList, 100, pss)).thenReturn(value);
		configrepo.insertMultipleConfigStg(configList);
		Mockito.verify(jdbcTemplate, Mockito.times(1)).batchUpdate(Mockito.anyString(), Mockito.anyList(),
				Mockito.anyInt(), Mockito.any());
	}

	@Test
	public void insertMultipleSegmentConfig_test() {
		String SQL_CONFIG_INSERT_MULTIPLE = "INSERT INTO " + "hive.platformops" + ".segment_config"
				+ "(config_id, tag_id, segment_id) VALUES(?, ?, ?)" + "";
		ParameterizedPreparedStatementSetter<ConfigEntity> pss = new ParameterizedPreparedStatementSetter<ConfigEntity>() {
			public void setValues(PreparedStatement ps, ConfigEntity configEntity) throws SQLException {
				ps.setInt(1, configEntity.getConfigId());
				ps.setString(2, configEntity.getTagId());
				ps.setInt(3, configEntity.getSegmentId());
			}
		};
		int[][] value = new int[3][3];
		value[0][0] = 1;
		value[1][0] = 1;
		Mockito.when(jdbcTemplate.batchUpdate(SQL_CONFIG_INSERT_MULTIPLE, configList, 100, pss)).thenReturn(value);
		configrepo.insertMultipleSegmentConfig(configList);
		Mockito.verify(jdbcTemplate, Mockito.times(1)).batchUpdate(Mockito.anyString(), Mockito.anyList(),
				Mockito.anyInt(), Mockito.any());
	}

}
