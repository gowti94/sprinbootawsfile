package com.programmatic.segment.service;

import static org.junit.Assert.assertEquals;

import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.programmatic.segment.entity.AccountsEntity;
import com.programmatic.segment.model.AccountsModel;
import com.programmatic.segment.model.RequestEntity;
import com.programmatic.segment.model.Response;
import com.programmatic.segment.repository.FailureAccountsRepository;
import com.programmatic.segment.repository.FileRepository;
import com.programmatic.segment.serviceimpl.WebClientServiceImpl;

/**
 * @author wajeeha.k
 *
 */

@EnableRetry(proxyTargetClass = true)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { WebClientServiceImpl.class })
@TestPropertySource(properties = { "​​​​​​​retry.time=3", "retry.delay=1000", "retry.multiplier=2" })
public class WebClientServiceTest {

	@Autowired
	WebClientService webClient;

	@MockBean
	RestTemplate restTemplate;

	@MockBean
	FileRepository filerepo;

	@MockBean
	FailureAccountsRepository errorRepo;

	private List<AccountsEntity> accountsList;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(webClient, "orgId", "4");
		ReflectionTestUtils.setField(webClient, "url", "https://aa-api-platform.dev.6si.com");
		accountsList = createAccountsList();
	}

	private List<AccountsEntity> createAccountsList() {
		AccountsEntity accountsEntity1 = new AccountsEntity(1, "abs", "usa", "xys.com", "ab", 1);
		AccountsEntity accountsEntity2 = new AccountsEntity(2, "abss", "usa", "xyss.com", "ab", 1);
		List<AccountsEntity> list = new ArrayList<>();
		list.add(accountsEntity1);
		list.add(accountsEntity2);
		return list;
	}

	@Test
	public void pushAccountsToSegment_test() {

		ResponseEntity responseEntityMock = Mockito.mock(ResponseEntity.class);
		Mockito.when(responseEntityMock.getStatusCode()).thenReturn(HttpStatus.OK);

		Mockito.when(restTemplate.exchange(ArgumentMatchers.any(URI.class), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.any(HttpEntity.class), ArgumentMatchers.any(Class.class)))
				.thenReturn(responseEntityMock);

		Gson gson = new Gson();
		List<AccountsModel> accountModellist = new ArrayList<>();
		for (AccountsEntity accounts : accountsList) {
			AccountsModel accountModel = new AccountsModel();
			accountModel.setName(accounts.getName());
			accountModel.setCountry(accounts.getCountry());
			accountModel.setDomain(accounts.getDomain());
			accountModellist.add(accountModel);
		}

		RequestEntity requestEntity = new RequestEntity();
		requestEntity.setEditedBy("pete@6sense.com");
		requestEntity.setAccounts(accountModellist);
		Integer segmentId = 72806;
		Integer fileId = 1;
		String request = gson.toJson(requestEntity);
		Integer result = webClient.pushAccountsToSegment(new Date(), accountModellist.size(), fileId, request, segmentId);
		Mockito.verify(restTemplate, Mockito.times(1)).exchange(ArgumentMatchers.any(URI.class),
				ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(HttpEntity.class),
				ArgumentMatchers.any(Class.class));
		assertEquals(result.longValue(), accountModellist.size());
	}

}
