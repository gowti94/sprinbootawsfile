package com.programmatic.segment.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.programmatic.segment.repository.AccountsRepository;
import com.programmatic.segment.repository.ConfigRepository;
import com.programmatic.segment.repository.FailureAccountsRepository;
import com.programmatic.segment.repository.FileRepository;
import com.programmatic.segment.serviceimpl.AWSS3DownloadServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
@PrepareForTest({ListObjectsV2Result.class, ListObjectsV2Request.class, AWSS3DownloadServiceImpl.class})
public class AWSS3DownloadServiceTest {

    @InjectMocks
    AWSS3DownloadServiceImpl awssvc;

    @Mock
    AccountsRepository accountsRepository;

    @Mock
    ConfigRepository configRepository;

    @Mock
    FileRepository fileRepository;

    @Mock
    FailureAccountsRepository failureRepo;

    @Mock
    SegmentProcessService apiService;

    @Mock
    DBService dbSvc;

    @Mock
    AmazonS3 amazonS3;

    @Mock
    ListObjectsV2Request listObjectsV2Request;


    private String bucketName = "s3://6sense-test/globaltest";
    private String accountsfileLocation = "/outgoing/crystal-ball/";
    private String configFileLocation = "/outgoing/crystal-ball/configs/";


    @Before
    public void setUp() throws Exception {
        ReflectionTestUtils.setField(awssvc, "accountsRepository", accountsRepository);
        ReflectionTestUtils.setField(awssvc, "configRepository", configRepository);
        ReflectionTestUtils.setField(awssvc, "fileRepository", fileRepository);
        ReflectionTestUtils.setField(awssvc, "failureRepo", failureRepo);
        ReflectionTestUtils.setField(awssvc, "apiService", apiService);
        ReflectionTestUtils.setField(awssvc, "accountsfileLocation", "/outgoing/crystal-ball/");
        ReflectionTestUtils.setField(awssvc, "configfileLocation", "/outgoing/crystall-ball/configs/");
        ReflectionTestUtils.setField(awssvc, "processedloc", "/outgoing/processed/");
        ReflectionTestUtils.setField(awssvc, "errorLocation", "/outgoing/error/");
        ReflectionTestUtils.setField(awssvc, "filenameConvention", "SAP-CRYSTALBALL");
        ReflectionTestUtils.setField(awssvc, "bucketName", "s3://6sense-test/globaltest");
        ReflectionTestUtils.setField(awssvc, "bucketRegion", "us-east-1");
        ReflectionTestUtils.setField(awssvc, "s3Client", amazonS3);

    }


    @Test
    public void download_configReading_test() throws Exception {
        ListObjectsV2Request listObjectsV2RequestMock = PowerMockito.mock(ListObjectsV2Request.class);
        ListObjectsV2Result listObjectsV2Result = Mockito.mock(ListObjectsV2Result.class);
        S3ObjectSummary s3ObjectSummary         = new S3ObjectSummary();
        s3ObjectSummary.setKey("config.xml");

        String configData = "<segmentGroup><tag>72807</tag><segment>83557</segment></segmentGroup>";
        S3Object s3Object = new S3Object();
        s3Object.setObjectContent(new ByteArrayInputStream(configData.getBytes(StandardCharsets.UTF_8)));

        Mockito.when(amazonS3.listObjectsV2(Mockito.any(ListObjectsV2Request.class))).thenReturn(listObjectsV2Result);

        Mockito.when(listObjectsV2Result.getObjectSummaries()).thenReturn(Arrays.asList(s3ObjectSummary));
        Mockito.when(amazonS3.getObject(Mockito.anyString(), Mockito.anyString())).thenReturn(s3Object);

        awssvc.download(new Date());

        Mockito.verify(configRepository, Mockito.times(1)).insertMultipleConfigStg(Mockito.any(List.class));
    }

    @Test
    public void download_AccountReading_test() throws Exception {
        /*
        Config file mock
         */

        ListObjectsV2Result listObjectsV2Result = Mockito.mock(ListObjectsV2Result.class);
        S3ObjectSummary s3ObjectSummary         = new S3ObjectSummary();
        s3ObjectSummary.setKey("config.xml");

        String configData = "<segmentGroup><tag>72807</tag><segment>72807</segment></segmentGroup>";
        S3Object s3Object = new S3Object();
        s3Object.setObjectContent(new ByteArrayInputStream(configData.getBytes(StandardCharsets.UTF_8)));

        /*
        Account file mock
         */
        ListObjectsV2Result listObjectsV2ResultAccount = Mockito.mock(ListObjectsV2Result.class);
        S3ObjectSummary s3ObjectSummaryAccount         = new S3ObjectSummary();
        s3ObjectSummaryAccount.setKey("accounts.csv");

        String accountData = "domain,company_name,domain_origin,score,tag_id\n" +
                "test.net,Testing Point,United States,80,[status]CB_Testing Point_Segment_A_20210131\n";
        S3Object s3ObjectAccount = new S3Object();
        s3ObjectAccount.setObjectContent(new ByteArrayInputStream(accountData.getBytes(StandardCharsets.UTF_8)));

        Mockito.when(amazonS3.listObjectsV2(Mockito.any(ListObjectsV2Request.class))).thenReturn(listObjectsV2Result).thenReturn(listObjectsV2ResultAccount);
        Mockito.when(listObjectsV2Result.getObjectSummaries()).thenReturn(Arrays.asList(s3ObjectSummary));
        Mockito.when(amazonS3.getObject(Mockito.anyString(), Mockito.anyString())).thenReturn(s3Object).thenReturn(s3ObjectAccount);
        Mockito.when(listObjectsV2ResultAccount.getObjectSummaries()).thenReturn(Arrays.asList(s3ObjectSummaryAccount));

        awssvc.download(new Date());
        Mockito.verify(configRepository, Mockito.times(1)).insertMultipleConfigStg(Mockito.any(List.class));
    }

}
