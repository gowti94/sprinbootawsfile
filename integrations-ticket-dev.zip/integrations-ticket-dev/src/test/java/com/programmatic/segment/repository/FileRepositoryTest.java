package com.programmatic.segment.repository;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.programmatic.segment.entity.FileEntity;

/**
 * @author wajeeha.k
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class FileRepositoryTest {

	@Mock
	JdbcTemplate jdbcTemplate;

	@InjectMocks
	FileRepository filerepo;

	private FileEntity file;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(filerepo, "jdbcTemplate", jdbcTemplate);
		file = createFileEntity();
		ReflectionTestUtils.setField(filerepo, "dbName", "hive.platformops");
	}

	

	private FileEntity createFileEntity() {
		FileEntity fileEntity = new FileEntity(1, "users.xlsx", new Date(), new Date(), "PROCESS_COMPLETED", 10);
		return fileEntity;
	}

	@Test
	public void getFileID_test() {
		String SQL_FILE_ID_SELECT = "SELECT COALESCE(MAX(file_id), 0) " + "as file_id from " + "hive.platformops"
				+ ".accounts_file";
		Map<String, Object> map = new HashMap<>();
		map.put("file_id", 1);
		Mockito.when(jdbcTemplate.queryForMap(SQL_FILE_ID_SELECT)).thenReturn(map);
		Integer id = filerepo.getFileID();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).queryForMap(Mockito.anyString());
		assertEquals(id.longValue(), file.getFileId().longValue());

	}

	@Test
	public void insertFile_test() {
		String SQL_FILE_INSERT_SINGLE = "INSERT INTO " + "hive.platformops" + ".accounts_file "
				+ "(file_id, file_name, process_start_datetime, process_end_datetime, status, "
				+ "noofrecordsprocessed) VALUES(?, ?, ?, ?, ?, ?)";
		Object[] params = new Object[] { 1, "users.xlsx", new Date(), new Date(), "PROCESS_COMPLETED", 10 };

		Integer value = 2;
		Mockito.when(jdbcTemplate.update(SQL_FILE_INSERT_SINGLE, params)).thenReturn(value);
		filerepo.insertFile(file);
	}

	@Test
	public void getFileIdByFilename_test() {
		String SQL_SELECT_FILE = "SELECT * FROM " + "hive.platformops" + ".accounts_file WHERE file_name = ?";
		Map<String, Object> map = new HashMap<>();
		map.put("file_id", 1);
		Mockito.when(jdbcTemplate.queryForMap(SQL_SELECT_FILE, file.getFileName())).thenReturn(map);
		Integer id = filerepo.getFileIdByFilename(file.getFileName());
		Mockito.verify(jdbcTemplate, Mockito.times(1)).queryForMap(Mockito.anyString(), Mockito.anyString());
		assertEquals(id.longValue(), file.getFileId().longValue());
	}

	@Test
	public void getFileByFileId_test() {
		Map<String, Object> map = new HashMap<>();
		map.put("file_id", 1);
		map.put("file_name", "users.xlsx");
		map.put("process_start_datetime", new Date());
		map.put("process_end_datetime", new Date());
		map.put("status", "PROCESS_COMPLETED");
		map.put("noofrecordsprocessed", 10);
		Mockito.when(jdbcTemplate.queryForMap(Mockito.anyString(), Mockito.anyInt())).thenReturn(map);
		Map<String, Object> actual = filerepo.getFileByFileId(file.getFileId());
		Mockito.verify(jdbcTemplate, Mockito.times(1)).queryForMap(Mockito.anyString(), Mockito.anyInt());
		assertEquals(actual.get("file_id"), file.getFileId());
	}

	@Test
	public void deleteFiles_test() {
		filerepo.deleteFiles();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).execute(Mockito.anyString());
	}

}
