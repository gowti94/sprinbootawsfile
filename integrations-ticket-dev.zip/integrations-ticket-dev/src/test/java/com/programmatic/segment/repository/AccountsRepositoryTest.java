package com.programmatic.segment.repository;

import static org.junit.Assert.assertEquals;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.test.util.ReflectionTestUtils;

import com.programmatic.segment.entity.AccountsEntity;

/**
 * @author wajeeha.k
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class AccountsRepositoryTest {

	@Mock
	JdbcTemplate jdbcTemplate;

	@InjectMocks
	AccountsRepository accountsrepo;

	private List<AccountsEntity> accountsList;

	private AccountsEntity accounts;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(accountsrepo, "jdbcTemplate", jdbcTemplate);
		accounts = createAccountsEntity();
		accountsList = createAccountsList();
		ReflectionTestUtils.setField(accountsrepo, "dbName", "hive.platformops");
	}

	private List<AccountsEntity> createAccountsList() {
		AccountsEntity accountsEntity1 = new AccountsEntity(1, "abs", "usa", "xys.com", "ab", 1);
		AccountsEntity accountsEntity2 = new AccountsEntity(2, "abss", "usa", "xyss.com", "ab", 1);
		List<AccountsEntity> list = new ArrayList<>();
		list.add(accountsEntity1);
		list.add(accountsEntity2);
		return list;
	}

	private AccountsEntity createAccountsEntity() {
		AccountsEntity accountsEntity = new AccountsEntity(1, "abs", "usa", "xys.com", "ab", 1);
		return accountsEntity;
	}

	@Test
	public void getAccountID_Test() {
		String sql = "SELECT COALESCE(MAX(account_id), 0) as account_id from " + "hive.platformops" + ".accounts";
		Map<String, Object> map = new HashMap<>();
		map.put("account_id", 1);
		map.put("name", "abs");
		map.put("country", "usa");
		map.put("domain", "xys.com");
		map.put("tag_id", 1);
		map.put("file_id", 1);
		Mockito.when(jdbcTemplate.queryForMap(sql)).thenReturn(map);
		Integer id = accountsrepo.getAccountID();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).queryForMap(Mockito.any());
		assertEquals(id.longValue(), accounts.getAccountId().longValue());
	}

	@Test
	public void insertMultipleAccounts_Test() {
		String sql = "INSERT INTO " + "hive.platformops" + ".accounts"
				+ "(account_id, name, country, \"domain\", tag_id, file_id) " + "VALUES " + "(?, ?, ?, ?, ?, ?)";
		ParameterizedPreparedStatementSetter<AccountsEntity> pss = new ParameterizedPreparedStatementSetter<AccountsEntity>() {
			public void setValues(PreparedStatement ps, AccountsEntity argument) throws SQLException {
				ps.setInt(1, argument.getAccountId());
				ps.setString(2, argument.getName());
				ps.setString(3, argument.getCountry());
				ps.setString(4, argument.getDomain());
				ps.setString(5, argument.getTagId());
				ps.setInt(6, argument.getFileId());
			}
		};
		int[][] value = new int[3][3];
		value[0][0] = 1;
		value[1][0] = 1;
		Mockito.when(jdbcTemplate.batchUpdate(sql, accountsList, 200, pss)).thenReturn(value);
		accountsrepo.insertMultiple(accountsList);
		Mockito.verify(jdbcTemplate, Mockito.times(1)).batchUpdate(Mockito.anyString(), Mockito.anyList(),
				Mockito.anyInt(), Mockito.any());

	}

}
