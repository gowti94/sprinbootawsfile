package com.programmatic.segment.repository;

import static org.junit.Assert.assertEquals;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.test.util.ReflectionTestUtils;

import com.programmatic.segment.entity.FailureAccountsEntity;

/**
 * @author wajeeha.k
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class FailureAccountsRepositoryTest {

	@Mock
	JdbcTemplate jdbcTemplate;

	@InjectMocks
	FailureAccountsRepository errorAccountsrepo;

	private List<FailureAccountsEntity> errorAccountsList = new ArrayList<>();
	private FailureAccountsEntity errorAccounts;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(errorAccountsrepo, "jdbcTemplate", jdbcTemplate);
		errorAccounts = createFailureAccountsEntity();
		errorAccountsList = createFailureAccountsList();
		ReflectionTestUtils.setField(errorAccountsrepo, "dbName", "hive.platformops");
	}

	private List<FailureAccountsEntity> createFailureAccountsList() {
		List<FailureAccountsEntity> list = new ArrayList<>();
		FailureAccountsEntity errorAccountsEntity = new FailureAccountsEntity(2, "abdc", "canada", "xsvc.xom", "", 1);
		list.add(createFailureAccountsEntity());
		list.add(errorAccountsEntity);
		return list;
	}

	private FailureAccountsEntity createFailureAccountsEntity() {
		FailureAccountsEntity errorAccountsEntity = new FailureAccountsEntity(1, "abd", "canada", "xvc.xom", "", 1);
		return errorAccountsEntity;
	}

	@Test
	public void getFailureAccountsID_test() {
		String SQL_ACCOUNTS_ID_SELECT = "SELECT COALESCE(MAX(error_account_id), 0) as error_account_id from "
				+ "hive.platformops" + ".error_accounts";
		Map<String, Object> map = new HashMap<>();
		map.put("error_account_id", 1);
		Mockito.when(jdbcTemplate.queryForMap(SQL_ACCOUNTS_ID_SELECT)).thenReturn(map);
		Integer id = errorAccountsrepo.getErrorAccountID();
		Mockito.verify(jdbcTemplate, Mockito.times(1)).queryForMap(Mockito.anyString());
		assertEquals(id.longValue(), errorAccounts.getErrorAccountId().longValue());

	}

	@Test
	public void insertMultipleErrorAccounts_Test() {
		String SQL_FAILURE_INSERT_MULTIPLE = "INSERT INTO " + "hive.platformops" + ".error_accounts"
				+ " (error_account_id, \"domain\", company, country, message, file_id) VALUES(?, ?, ?, ?, ?, ?)";
		ParameterizedPreparedStatementSetter<FailureAccountsEntity> pss = new ParameterizedPreparedStatementSetter<FailureAccountsEntity>() {
			public void setValues(PreparedStatement ps, FailureAccountsEntity argument) throws SQLException {
				ps.setInt(1, argument.getErrorAccountId());
				ps.setString(2, argument.getName());
				ps.setString(3, argument.getCountry());
				ps.setString(4, argument.getDomain());
				ps.setString(5, argument.getMessage());
				ps.setInt(6, argument.getFileId());
			}
		};
		int[][] value = new int[3][3];
		value[0][0] = 1;
		value[1][0] = 1;
		Mockito.when(jdbcTemplate.batchUpdate(SQL_FAILURE_INSERT_MULTIPLE, errorAccountsList, 100, pss))
				.thenReturn(value);
		errorAccountsrepo.insertMultipleErrorAccounts(errorAccountsList);
		Mockito.verify(jdbcTemplate, Mockito.times(1)).batchUpdate(Mockito.anyString(), Mockito.anyList(),
				Mockito.anyInt(), Mockito.any());

	}

}
