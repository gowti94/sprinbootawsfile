package com.programmatic.segment.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.programmatic.segment.entity.AccountsEntity;
import com.programmatic.segment.model.SegmentModel;
import com.programmatic.segment.repository.AccountsRepository;
import com.programmatic.segment.repository.ConfigRepository;
import com.programmatic.segment.repository.FailureAccountsRepository;
import com.programmatic.segment.repository.FileRepository;
import com.programmatic.segment.serviceimpl.SegmentProcessServiceImpl;

/**
 * @author wajeeha.k
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class SegmentProcessServiceTest {

	@InjectMocks
	SegmentProcessServiceImpl segmentProcessService;

	@Mock
	ConfigRepository configrepo;

	@Mock
	AccountsRepository accountsrepo;

	@Mock
	FileRepository filerepo;

	@Mock
	FailureAccountsRepository errorRepo;

	@Mock
	AWSS3DownloadService awss3DownloadService;

	@Mock
	WebClientService webClientService;

	private List<AccountsEntity> accountsList;

	@Before
	public void setUp() throws Exception {
		ReflectionTestUtils.setField(segmentProcessService, "configrepo", configrepo);
		ReflectionTestUtils.setField(segmentProcessService, "accountsrepo", accountsrepo);
		ReflectionTestUtils.setField(segmentProcessService, "filerepo", filerepo);
		ReflectionTestUtils.setField(segmentProcessService, "errorRepo", errorRepo);
		ReflectionTestUtils.setField(segmentProcessService, "awss3DownloadService", awss3DownloadService);
		ReflectionTestUtils.setField(segmentProcessService, "webclientserv", webClientService);
		accountsList = createAccountsList();
	}

	private List<AccountsEntity> createAccountsList() {
		AccountsEntity accountsEntity1 = new AccountsEntity(1, "abs", "usa", "xys.com", "ab", 1);
		AccountsEntity accountsEntity2 = new AccountsEntity(2, "abss", "usa", "xyss.com", "ab", 1);
		List<AccountsEntity> list = new ArrayList<>();
		list.add(accountsEntity1);
		list.add(accountsEntity2);
		return list;
	}

	@Test
	public void matchAccountsWithSegment_test() {
		List<SegmentModel> segmentlist = new ArrayList<>();
		Date date = new Date();
		SegmentModel segment1 = new SegmentModel("usa", "abs", "xys.com", 72806);
		SegmentModel segment2 = new SegmentModel("usa", "abss", "xyss.com", 72806);
		segmentlist.add(segment1);
		segmentlist.add(segment2);
		Mockito.when(accountsrepo.selectFromAccountsConfig(Mockito.anyInt())).thenReturn(segmentlist);
		segmentProcessService.matchAccountsWithSegment(date, 1, accountsList);
		Mockito.verify(accountsrepo, Mockito.times(1)).selectFromAccountsConfig(Mockito.anyInt());
		String resultJson = "{\"edited_by\":\"pete@6sense.com\",\"accounts\":[{\"name\":\"abs\",\"country\":\"usa\",\"domain\":\"xys.com\"},{\"name\":\"abss\",\"country\":\"usa\",\"domain\":\"xyss.com\"}]}";
		Mockito.verify(webClientService, Mockito.times(1)).pushAccountsToSegment(date, 2, 1, resultJson, 72806);

	}

}
