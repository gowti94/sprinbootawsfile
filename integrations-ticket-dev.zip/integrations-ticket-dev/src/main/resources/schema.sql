CREATE TABLE IF NOT EXISTS hive.sapglobal.accounts (
	account_id integer,
	name varchar,
	country varchar,
	"domain" varchar,
	tag_id varchar,
	file_id integer
);

CREATE TABLE IF NOT EXISTS hive.sapglobal.accounts_file (
	file_id integer,
	file_name varchar,
	process_start_datetime timestamp,
	process_end_datetime timestamp,
	status varchar,
	noofrecordsprocessed integer
);

CREATE TABLE IF NOT EXISTS hive.sapglobal.error_accounts (
	error_account_id integer,
	"domain" varchar,
	company varchar,
	country varchar,
	message varchar,
	file_id integer
);

CREATE TABLE IF NOT EXISTS hive.sapglobal.config_stg (
	tag_id varchar,
	segment_id integer
);

CREATE TABLE IF NOT EXISTS hive.sapglobal.segment_config (
	config_id integer,
	tag_id varchar,
	segment_id integer
);
