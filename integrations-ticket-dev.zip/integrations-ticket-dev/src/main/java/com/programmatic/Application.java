package com.programmatic;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.retry.annotation.EnableRetry;
import com.programmatic.segment.service.RunnerService;

/**
 * @author wajeeha.k
 *
 */
@EnableRetry
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
public class Application implements CommandLineRunner {
	@Autowired
	RunnerService runnerService;
	private static final Logger logger = LogManager.getLogger(Application.class);

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(Application.class);
		application.setWebApplicationType(WebApplicationType.NONE);
		application.run(args).close();
		System.exit(0);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Start Execution at - " + new Date());
		try {
			runnerService.run(new Date());
		} catch (Exception e) {
			logger.info("Execution failed with -> {​​​​​​​}​​​​​​​", e);
			System.exit(0);
		}
		logger.info("End Execution  at - " + new Date());
	}
}
