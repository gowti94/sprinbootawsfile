package com.programmatic.segment.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.programmatic.segment.entity.AccountsEntity;

public interface DBService {

	public void saveAccountsToDb(List<AccountsEntity> list);
}
