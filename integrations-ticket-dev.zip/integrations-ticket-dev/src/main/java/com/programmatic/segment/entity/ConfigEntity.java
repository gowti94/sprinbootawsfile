package com.programmatic.segment.entity;

/**
 * @author wajeeha.k
 *
 */
public class ConfigEntity {

	private Integer configId;

	private String tagId;

	private Integer segmentId;

	public ConfigEntity() {

	}

	/**
	 * @param configId
	 * @param tagId
	 * @param segmentId
	 */
	public ConfigEntity(Integer configId, String tagId, Integer segmentId) {
		this.configId = configId;
		this.tagId = tagId;
		this.segmentId = segmentId;
	}

	@Override
	public String toString() {
		return "ConfigEntity [configId=" + configId + ", tagId=" + tagId + ", segmentId=" + segmentId + "]";
	}

	public Integer getConfigId() {
		return configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

}
