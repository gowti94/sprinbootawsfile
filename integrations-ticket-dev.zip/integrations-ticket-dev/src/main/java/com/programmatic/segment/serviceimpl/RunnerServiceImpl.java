package com.programmatic.segment.serviceimpl;

import java.util.Date;

import com.programmatic.segment.service.AWSS3DownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.programmatic.segment.service.RunnerService;

/**
 * @author wajeeha.k
 *
 */
@Service
public class RunnerServiceImpl implements RunnerService {

	@Autowired
	AWSS3DownloadService awsDownloadService;

	@Override
	public void run(Date date) {
		awsDownloadService.connect();
		awsDownloadService.download(date);
		awsDownloadService.disconnect();
	}
}
