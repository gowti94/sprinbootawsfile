package com.programmatic.segment.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.programmatic.segment.entity.AccountsEntity;
import com.programmatic.segment.model.SegmentModel;

/**
 * @author wajeeha.k
 *
 */
@Repository
public class AccountsRepository {

	@Autowired
	@Qualifier("prestoTemplate")
	private JdbcTemplate jdbcTemplate;

	@Value("${segment.database}")
	private String dbName;

	private static final Logger logger = LogManager.getLogger(AccountsRepository.class);

	public Integer getAccountID() {
		String SQL_ACCOUNTS_ID_SELECT = "SELECT COALESCE(MAX(account_id), 0) as account_id from " + dbName
				+ ".accounts";
		Map<String, Object> result = jdbcTemplate.queryForMap(SQL_ACCOUNTS_ID_SELECT);
		return (Integer) result.get("account_id");
	}

	public int[][] insertMultiple(List<AccountsEntity> accountsList) {
		logger.info("Inserting into Accounts");
		String SQL_ACCOUNTS_INSERT_MULTIPLE = "INSERT INTO " + dbName + ".accounts"
				+ "(account_id, name, country, \"domain\", tag_id, file_id) " + "VALUES " + "(?, ?, ?, ?, ?, ?)";
		return jdbcTemplate.batchUpdate(SQL_ACCOUNTS_INSERT_MULTIPLE, accountsList, 200,
				new ParameterizedPreparedStatementSetter<AccountsEntity>() {
					public void setValues(PreparedStatement ps, AccountsEntity argument) throws SQLException {
						logger.info("Inserting record {}", argument.getAccountId());
						ps.setInt(1, argument.getAccountId());
						ps.setString(2, argument.getName());
						ps.setString(3, argument.getCountry());
						ps.setString(4, argument.getDomain());
						ps.setString(5, argument.getTagId());
						ps.setInt(6, argument.getFileId());
					}
				});
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<SegmentModel> selectFromAccountsConfig(Integer fileId) {
		logger.info("Inside Accounts Select Config");
		String SQL_ACCOUNTS_TAG_MULTIPLE = "SELECT name, country, \"domain\", segment_id FROM " + dbName + ".accounts, "
				+ dbName + ".segment_config WHERE " + dbName + ".segment_config.tag_id = " + dbName
				+ ".accounts.tag_id AND " + dbName + ".accounts.file_id = ?"
				+ " GROUP by name, country, \"domain\", segment_id ORDER by segment_id";
		List<SegmentModel> segList = jdbcTemplate.query(SQL_ACCOUNTS_TAG_MULTIPLE,
				new BeanPropertyRowMapper(SegmentModel.class), fileId);
		return segList;
	}

}
