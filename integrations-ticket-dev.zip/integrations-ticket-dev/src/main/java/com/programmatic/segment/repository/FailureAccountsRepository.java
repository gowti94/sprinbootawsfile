package com.programmatic.segment.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.programmatic.segment.entity.FailureAccountsEntity;

/**
 * @author wajeeha.k
 *
 */
@Repository
public class FailureAccountsRepository {

	@Autowired
	@Qualifier("prestoTemplate")
	private JdbcTemplate jdbcTemplate;

	@Value("${segment.database}")
	private String dbName;

	private static final Logger logger = LogManager.getLogger(FailureAccountsRepository.class);

	public Integer getErrorAccountID() {
		String SQL_ACCOUNTS_ID_SELECT = "SELECT COALESCE(MAX(error_account_id), 0) as error_account_id from " + dbName
				+ ".error_accounts";
		Map<String, Object> result = jdbcTemplate.queryForMap(SQL_ACCOUNTS_ID_SELECT);
		return (Integer) result.get("error_account_id");
	}

	public void insertMultipleErrorAccounts(List<FailureAccountsEntity> erroraccountsList) {
		String SQL_FAILURE_INSERT_MULTIPLE = "INSERT INTO " + dbName + ".error_accounts"
				+ " (error_account_id, \"domain\", company, country, message, file_id) VALUES(?, ?, ?, ?, ?, ?)";
		logger.info("Inserting into error_accounts");
		jdbcTemplate.batchUpdate(SQL_FAILURE_INSERT_MULTIPLE, erroraccountsList, 100,
				new ParameterizedPreparedStatementSetter<FailureAccountsEntity>() {
					public void setValues(PreparedStatement ps, FailureAccountsEntity argument) throws SQLException {
						logger.info("Inserting record {}", argument.getErrorAccountId());
						ps.setInt(1, argument.getErrorAccountId());
						ps.setString(2, argument.getDomain());
						ps.setString(3, argument.getName());
						ps.setString(4, argument.getCountry());
						ps.setString(5, argument.getMessage());
						ps.setInt(6, argument.getFileId());
					}
				});
		logger.info("Finished Inserting into error_accounts");
	}

}
