package com.programmatic.segment.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.alibaba.druid.pool.DruidDataSource;

/**
 * @author wajeeha.k
 *
 */
@Configuration
public class PrestoConfig {

	@Bean(name = "prestoDataSource")
	@ConfigurationProperties(prefix = "spring.datasource.presto")
	public DataSource prestoDataSource() {
		return new DruidDataSource();
	}

	@Autowired
	@Qualifier("prestoDataSource")
	DataSource dataSource;

	@Bean(name = "prestoTemplate")
	public JdbcTemplate prestoJdbcTemplate() {
		return new JdbcTemplate(dataSource);
	}

}
