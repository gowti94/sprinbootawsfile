package com.programmatic.segment.service;

import java.util.Date;

/**
 * @author wajeeha.k
 *
 */
public interface RunnerService {

	void run(Date date);

}
