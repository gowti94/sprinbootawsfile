package com.programmatic.segment.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.Gson;
import com.programmatic.segment.entity.FailureAccountsEntity;
import com.programmatic.segment.entity.FileEntity;
import com.programmatic.segment.model.AccountsModel;
import com.programmatic.segment.model.RequestEntity;
import com.programmatic.segment.model.Response;
import com.programmatic.segment.repository.FailureAccountsRepository;
import com.programmatic.segment.repository.FileRepository;
import com.programmatic.segment.service.WebClientService;

/**
 * @author wajeeha.k
 *
 */
@Service
public class WebClientServiceImpl implements WebClientService {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	FileRepository filerepo;

	@Autowired
	FailureAccountsRepository errorRepo;

	@Value("${segment.org.id}")
	private String orgId;

	@Value("${segment.url}")
	private String url;

	private static final Logger logger = LogManager.getLogger(WebClientServiceImpl.class);

	@Override
	@Retryable(maxAttemptsExpression = "#{${retry.time}}", value = Exception.class, backoff = @Backoff(delayExpression = "#{${retry.delay}}", multiplierExpression = "#{${retry.multiplier}}", maxDelay = 1000
			* 60 * 15))
	public Integer pushAccountsToSegment(Date date, int totalNoOfAccounts, Integer fileId, String request,
			Integer segmentId) {
		logger.info("org {} : ", orgId + " segment id : "+segmentId);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> requestPayload = new HttpEntity<String>(request, headers);
		String uri = url + "/api/v1/internal/org/{orgId}/update_programmatic_segment/segment/{segmentId}/";

		// URI (URL) parameters
		Map<String, String> urlParams = new HashMap<>();
		urlParams.put("orgId", orgId);
		urlParams.put("segmentId", segmentId.toString());

		// Query parameters
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri);
		try {
			ResponseEntity<Response> response = restTemplate.exchange(builder.buildAndExpand(urlParams).toUri(),
					HttpMethod.PATCH, requestPayload, Response.class);
			if (response.getStatusCode().equals(HttpStatus.OK)) {
				logger.info("Response {}", response.getStatusCode().toString());
				RequestEntity entity = new RequestEntity();
				Gson gson = new Gson();
				entity = gson.fromJson(request, RequestEntity.class);
				saveFileDetailsWhenSuccess(date, fileId, entity.getAccounts().size());
				return totalNoOfAccounts;
			}
			return 0;
		} catch (RestClientResponseException e) {
			logger.info("Retrying due to {}" + e.getMessage());
			throw e;
		} catch (RuntimeException e) {
			logger.info("Runtime exception due to {}" + e.getMessage());
			throw e;
		}

	}

	@Recover
	public Integer saveErroneousAccountToDb(Exception exception, Date date, int totaNoOfAccounts, Integer fileId,
			String request, Integer segmentId) {
		logger.info("Into the Recover");
		Integer response = 0;
		List<FailureAccountsEntity> errorAccountsList = new ArrayList<>();
		RequestEntity requestEntity = new RequestEntity();
		Gson gson = new Gson();
		requestEntity = gson.fromJson(request, RequestEntity.class);
		Integer errorId = errorRepo.getErrorAccountID();
		for (AccountsModel accountsModel : requestEntity.getAccounts()) {
			FailureAccountsEntity failureAccountsEntity = new FailureAccountsEntity();
			failureAccountsEntity.setErrorAccountId(++errorId);
			failureAccountsEntity.setName(accountsModel.getName());
			failureAccountsEntity.setCountry(accountsModel.getCountry());
			failureAccountsEntity.setDomain(accountsModel.getDomain());
			failureAccountsEntity.setMessage(exception.getMessage());
			failureAccountsEntity.setFileId(fileId);
			errorAccountsList.add(failureAccountsEntity);
		}
		errorRepo.insertMultipleErrorAccounts(errorAccountsList);
		saveFileDetailsWhenFailure(date, fileId);
		logger.info("Completed the Recover");
		return response;
	}

	private void saveFileDetailsWhenSuccess(Date date, Integer fileId, Integer totalAccounts) {
		List<FileEntity> fileList = new ArrayList<>();
		fileList = filerepo.selectMultipleFiles();
		filerepo.deleteFiles();
		for (FileEntity file : fileList) {
			if (file.getFileId().equals(fileId.intValue())) {
				file.setProcessEndDateTime(new Date());
				file.setStatus("PROCESS_COMPLETED");
				file.setNoOfAccountsProcessed(file.getNoOfAccountsProcessed() + totalAccounts);
			}
		}
		fileList.stream().forEach(file -> filerepo.insertFile(file));
	}

	private void saveFileDetailsWhenFailure(Date date, Integer fileId) {
		List<FileEntity> fileList = new ArrayList<>();
		fileList = filerepo.selectMultipleFiles();
		filerepo.deleteFiles();
		for (FileEntity file : fileList) {
			if (file.getFileId().equals(fileId.intValue())) {
				file.setProcessEndDateTime(new Date());
				file.setStatus("PROCESS_FAILED/INTERUPPTED");
			}
		}
		fileList.stream().forEach(file -> filerepo.insertFile(file));
	}

}
