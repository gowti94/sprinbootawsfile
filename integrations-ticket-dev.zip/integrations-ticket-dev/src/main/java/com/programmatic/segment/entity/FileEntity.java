package com.programmatic.segment.entity;

import java.util.Date;

/**
 * @author wajeeha.k
 *
 */
public class FileEntity {

	private Integer fileId;

	private String fileName;

	private Date processStartDateTime;

	private Date processEndDateTime;

	private String status;

	private Integer noOfAccountsProcessed;

	public FileEntity() {

	}

	/**
	 * @param fileId
	 * @param fileName
	 * @param processStartDateTime
	 * @param processEndDateTime
	 * @param status
	 * @param noOfAccountsProcessed
	 */
	public FileEntity(Integer fileId, String fileName, Date processStartDateTime, Date processEndDateTime,
			String status, Integer noOfAccountsProcessed) {
		this.fileId = fileId;
		this.fileName = fileName;
		this.processStartDateTime = processStartDateTime;
		this.processEndDateTime = processEndDateTime;
		this.status = status;
		this.noOfAccountsProcessed = noOfAccountsProcessed;
	}

	public Integer getId() {
		return fileId;
	}

	public void setId(Integer id) {
		this.fileId = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public Integer getNoOfAccountsProcessed() {
		return noOfAccountsProcessed;
	}

	public void setNoOfAccountsProcessed(Integer noOfAccountsProcessed) {
		this.noOfAccountsProcessed = noOfAccountsProcessed;
	}

	public Date getProcessStartDateTime() {
		return processStartDateTime;
	}

	public void setProcessStartDateTime(Date processStartDateTime) {
		this.processStartDateTime = processStartDateTime;
	}

	public Date getProcessEndDateTime() {
		return processEndDateTime;
	}

	public void setProcessEndDateTime(Date processEndDateTime) {
		this.processEndDateTime = processEndDateTime;
	}

	@Override
	public String toString() {
		return "FileEntity [fileId=" + fileId + ", fileName=" + fileName + ", processStartDateTime="
				+ processStartDateTime + ", processEndDateTime=" + processEndDateTime + ", status=" + status
				+ ", noOfAccountsProcessed=" + noOfAccountsProcessed + "]";
	}
}
