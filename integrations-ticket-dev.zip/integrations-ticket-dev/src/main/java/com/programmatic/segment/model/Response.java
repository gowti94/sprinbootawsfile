package com.programmatic.segment.model;

/**
 * @author wajeeha.k
 *
 */
public class Response {

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
