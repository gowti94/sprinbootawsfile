package com.programmatic.segment.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.programmatic.segment.entity.AccountsEntity;
import com.programmatic.segment.repository.AccountsRepository;
import com.programmatic.segment.service.DBService;

@Service
public class DBServiceImpl implements DBService {

	@Autowired
	AccountsRepository accountsRepository;

	@Override
	public void saveAccountsToDb(List<AccountsEntity> list) {
		accountsRepository.insertMultiple(list);
	}

}
