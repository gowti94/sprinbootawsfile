package com.programmatic.segment.model;

/**
 * @author wajeeha.k
 *
 */
public class SegmentModel {

	private String country;

	private String name;

	private String domain;

	private Integer segmentId;

	public SegmentModel() {

	}

	/**
	 * @param country
	 * @param name
	 * @param domain
	 * @param segmentId
	 */
	public SegmentModel(String country, String name, String domain, Integer segmentId) {
		this.country = country;
		this.name = name;
		this.domain = domain;
		this.segmentId = segmentId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	@Override
	public String toString() {
		return "SegmentModel [country=" + country + ", name=" + name + ", domain=" + domain + ", segmentId=" + segmentId
				+ "]";
	}
}
