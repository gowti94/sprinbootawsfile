package com.programmatic.segment.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.programmatic.segment.service.AWSS3DownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.programmatic.segment.entity.AccountsEntity;
import com.programmatic.segment.model.AccountsModel;
import com.programmatic.segment.model.RequestEntity;
import com.programmatic.segment.model.SegmentModel;
import com.programmatic.segment.repository.AccountsRepository;
import com.programmatic.segment.repository.ConfigRepository;
import com.programmatic.segment.repository.FailureAccountsRepository;
import com.programmatic.segment.repository.FileRepository;
import com.programmatic.segment.service.SegmentProcessService;
import com.programmatic.segment.service.WebClientService;

/**
 * @author wajeeha.k
 *
 */
@Service
public class SegmentProcessServiceImpl implements SegmentProcessService {

	@Autowired
	ConfigRepository configrepo;

	@Autowired
	AccountsRepository accountsrepo;

	@Autowired
	FileRepository filerepo;

	@Autowired
	FailureAccountsRepository errorRepo;

	@Autowired
	AWSS3DownloadService awss3DownloadService;

	@Autowired
	WebClientService webclientserv;

	@Override
	public void matchAccountsWithSegment(Date date, Integer fileId, List<AccountsEntity> list) {
		List<SegmentModel> segment = accountsrepo.selectFromAccountsConfig(fileId);
		HashMap<Integer, List<AccountsModel>> map = formSegmentMap(segment);
		Integer totalNoOfrecords = 0;
		for (Map.Entry<Integer, List<AccountsModel>> entry : map.entrySet()) {
			if (entry.getValue().size() >= 5000) {
				int partitionSize = 5000;
				List<List<AccountsModel>> partitions = new ArrayList<>();

				for (int i = 0; i < entry.getValue().size(); i += partitionSize) {
					partitions.add(entry.getValue().subList(i, Math.min(i + partitionSize, entry.getValue().size())));
				}

				for (List<AccountsModel> partList : partitions) {
					totalNoOfrecords += convertToJson(date, fileId, partList, entry.getKey());
				}
			}
			totalNoOfrecords += convertToJson(date, fileId, entry.getValue(), entry.getKey());
		}
		if (totalNoOfrecords == segment.size()) {
			transferProcessedFile(fileId);
		}
	}

	private Integer convertToJson(Date date, Integer fileId, List<AccountsModel> list, Integer segmentId) {
		Gson gson = new GsonBuilder().disableHtmlEscaping().create();
		RequestEntity requestEntity = new RequestEntity();
		requestEntity.setEditedBy("pete@6sense.com");
		requestEntity.setAccounts(list);
		return webclientserv.pushAccountsToSegment(date, list.size(), fileId, gson.toJson(requestEntity), segmentId);
	}

	private HashMap<Integer, List<AccountsModel>> formSegmentMap(List<SegmentModel> segment) {
		HashMap<Integer, List<AccountsModel>> map = new HashMap<>();
		for (SegmentModel segm : segment) {
			if (!map.containsKey(segm.getSegmentId())) {
				List<AccountsModel> accountslist = new ArrayList<>();
				AccountsModel accounts = new AccountsModel();
				accounts.setName(segm.getName());
				accounts.setCountry(segm.getCountry());
				accounts.setDomain(segm.getDomain());
				accountslist.add(accounts);
				map.put(segm.getSegmentId(), accountslist);
			} else {
				List<AccountsModel> accountslist = map.get(segm.getSegmentId());
				AccountsModel accounts = new AccountsModel();
				accounts.setName(segm.getName());
				accounts.setCountry(segm.getCountry());
				accounts.setDomain(segm.getDomain());
				accountslist.add(accounts);
			}
		}
		return map;
	}

	private void transferProcessedFile(Integer fileId) {
		Map<String, Object> fileMap = filerepo.getFileByFileId(fileId);
		awss3DownloadService.transfer(fileMap.get("file_name").toString());
	}

}
