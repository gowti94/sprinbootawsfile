package com.programmatic.segment.serviceimpl;

import com.amazonaws.SdkBaseException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import com.programmatic.segment.entity.AccountsEntity;
import com.programmatic.segment.entity.ConfigEntity;
import com.programmatic.segment.entity.FailureAccountsEntity;
import com.programmatic.segment.entity.FileEntity;
import com.programmatic.segment.repository.AccountsRepository;
import com.programmatic.segment.repository.ConfigRepository;
import com.programmatic.segment.repository.FailureAccountsRepository;
import com.programmatic.segment.repository.FileRepository;
import com.programmatic.segment.service.AWSS3DownloadService;
import com.programmatic.segment.service.DBService;
import com.programmatic.segment.service.SegmentProcessService;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

@Service
public class AWSS3DownloadServiceImpl implements AWSS3DownloadService {

    @Autowired
    AccountsRepository accountsRepository;

    @Autowired
    ConfigRepository configRepository;

    @Autowired
    FileRepository fileRepository;

    @Autowired
    FailureAccountsRepository failureRepo;

    @Autowired
    SegmentProcessService apiService;

    @Autowired
    DBService dbSvc;


    @Value("${accounts.file.location}")
    private String accountsfileLocation;

    @Value("${config.file.location}")
    private String configfileLocation;

    @Value("${processed.file.location}")
    private String processedloc;

    @Value("${error.file.location}")
    private String errorLocation;

    @Value("${file.name.rule}")
    private String filenameConvention;

    @Value("${s3.bucket.name}")
    private String bucketName;

    @Value("${s3.bucket.region}")
    private String bucketRegion;

    private AmazonS3 s3Client;

    private static final Logger logger = LogManager.getLogger(AWSS3DownloadServiceImpl.class);


    @Override
    public void connect() {
        try {
            if (null == s3Client) {
                s3Client = AmazonS3ClientBuilder.standard()
                        .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                        .withRegion(Regions.fromName(bucketRegion))
                        .build();
            }
        } catch (SdkBaseException e){
            logger.error("Error connecting to AWS S3 {}", e.getMessage());
        }
    }

    @Override
    public void download(Date date) {
        connect();
        readConfigFile();
        readAccountFile(date);
        disconnect();
    }

    private void readConfigFile(){
        List<S3ObjectSummary> configFileList = new ArrayList<>();
        List<ConfigEntity> configEntityList = new ArrayList<>();

        try {
            logger.info("Bucket info is : bucket name -> "+  bucketName + " \t config file loc "+configfileLocation);
            ListObjectsV2Request listObjectsV2Request = new ListObjectsV2Request()
                                                            .withBucketName(bucketName)
                                                            .withPrefix(configfileLocation);
            configFileList = s3Client.listObjectsV2(listObjectsV2Request).getObjectSummaries();

        }catch(Exception exception) {
            logger.error("Error occurred when getting list of config files " + exception.getMessage());
        }

        configRepository.deleteSegConfig();
        Integer configID = configRepository.getConfigID();
        String configFile = StringUtils.EMPTY;

        for (int i = 0; i < configFileList.size(); i++) {
            if (null != configFileList.get(i))
                configFile = configFileList.get(i).getKey().substring(configFileList.get(i).getKey().lastIndexOf("/") + 1);
            InputStream stream = null;

            if (StringUtils.containsIgnoreCase(configFile, ".xml")) {
                try {
                    logger.info("Reading config file from S3");
                    logger.info("Bucket info is : bucket name -> "+  bucketName + " \t config file loc " +configFile);
                    stream = s3Client.getObject(bucketName,  configfileLocation + configFile).getObjectContent();
                    logger.info("Finished Reading config file from S3");
                } catch (SdkClientException exception) {
                    logger.error("Error during downloading config file {}" + exception.getMessage());
                }
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                try {
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document doc = null;
                    if (null != stream)
                        doc = builder.parse(stream);
                    stream.close();
                    if (null != doc)
                        doc.getDocumentElement().normalize();
                    NodeList nodes = doc.getElementsByTagName("segmentGroup");
                    for (int node = 0; node < nodes.getLength(); node++) {
                        Node nNode = nodes.item(node);
                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element eElement = (Element) nNode;
                            ConfigEntity config = new ConfigEntity();
                            config.setConfigId(++configID);
                            config.setTagId(eElement.getElementsByTagName("tag").item(0).getTextContent());
                            config.setSegmentId(
                                    Integer.valueOf(eElement.getElementsByTagName("segment").item(0).getTextContent()));
                            configEntityList.add(config);
                        }
                    }
                } catch (Exception ex) {
                    logger.error("Error parsing config file", ex.getMessage());
                }
                configRepository.insertMultipleConfigStg(configEntityList);
                configRepository.insertMultipleSegmentConfig(configEntityList);
            }
        }
    }

    private void readAccountFile(Date date){
        String filename = StringUtils.EMPTY;
        List<S3ObjectSummary> accountFileList = new ArrayList<>();
        try {
            logger.info("Reading account file. Bucket info is : bucket name -> "+  bucketName + " \t account file loc "+accountsfileLocation);
            ListObjectsV2Request listObjectsV2Request = new ListObjectsV2Request()
                    .withBucketName(bucketName)
                    .withPrefix(accountsfileLocation);
            accountFileList = s3Client.listObjectsV2(listObjectsV2Request).getObjectSummaries();
        } catch (Exception exception) {
            logger.error("Error downloading files from outgoing folder"+ exception.getMessage());
        }

        Integer fileId = fileRepository.getFileID();
        for (int i = 0; i < accountFileList.size(); i++) {
            FileEntity fileDetails = new FileEntity();
            if (null != accountFileList.get(i))
                filename = accountFileList.get(i).getKey().substring(accountFileList.get(i).getKey().lastIndexOf("/") + 1);
            if (StringUtils.containsIgnoreCase(filename, filenameConvention)) {
                if (StringUtils.containsIgnoreCase(filename, ".xlsx")
                        || StringUtils.containsIgnoreCase(filename, ".csv")
                        || StringUtils.containsIgnoreCase(filename, ".tsv")
                        || StringUtils.containsIgnoreCase(filename, ".txt")) {
                    fileDetails.setFileId(++fileId);
                    fileDetails.setFileName(filename);
                    fileDetails.setProcessStartDateTime(new Date());
                    fileDetails.setProcessEndDateTime(new Date());
                    fileDetails.setNoOfAccountsProcessed(0);
                    fileDetails.setStatus("PROCESS_STARTED");
                    saveFileInfoToDb(fileDetails);
                    InputStream stream = null;

                    try {
                        logger.info("Reading accounts file from source " + accountsfileLocation + filename);
                        stream = s3Client.getObject(bucketName,accountsfileLocation + filename).getObjectContent();
                        logger.info("Finished Reading accounts file from source");
                    } catch ( SdkClientException e) {
                        logger.error("Error getting accounts file from sftp", e.getMessage());
                        connect();
                        try {
                            s3Client.copyObject(bucketName, accountsfileLocation + filename, bucketName, errorLocation + filename);
                            logger.info("copied erroneous file from account folder to diagnostic folder {}" + filename);
                            s3Client.deleteObject(bucketName, accountsfileLocation + filename);
                            logger.info("Transferred erroneous file to diagnostic folder {}" + filename);
                        } catch ( SdkClientException exception) {
                            logger.error("Error occurred during moving file from S3 due to {}",
                                    exception.getMessage());
                        }
                    }
                    List<AccountsEntity> accountsDetailsList = new ArrayList<>();
                    Integer accountID = accountsRepository.getAccountID();
                    if (StringUtils.containsIgnoreCase(filename, ".xlsx")) {

                        @SuppressWarnings("resource")
                        XSSFWorkbook xssfWorkbook = new XSSFWorkbook();
                        try {
                            xssfWorkbook = new XSSFWorkbook(stream);
                        } catch (IOException e) {
                            logger.error("Error reading accounts file {}", e.getMessage());
                        }
                        XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(0);
                        int rowCount = xssfSheet.getLastRowNum() - xssfSheet.getFirstRowNum();
                        for (int index = 1; index < rowCount + 1; index++) {
                            Row row = xssfSheet.getRow(index);
                            AccountsEntity accountsDetails = new AccountsEntity();
                            accountsDetails.setDomain(
                                    null == row.getCell(0) ? StringUtils.EMPTY : row.getCell(0).getStringCellValue());
                            accountsDetails.setName(
                                    null == row.getCell(1) ? StringUtils.EMPTY : row.getCell(1).getStringCellValue());
                            accountsDetails.setCountry(
                                    null == row.getCell(2) ? StringUtils.EMPTY : row.getCell(2).getStringCellValue());
                            accountsDetails.setTagId(
                                    null == row.getCell(4) ? StringUtils.EMPTY : row.getCell(4).getStringCellValue());
                            accountsDetails.setFileId(fileId);
                            accountsDetailsList.add(accountsDetails);
                        }
                    }
                    if (StringUtils.containsIgnoreCase(filename, ".csv")) {
                        List<String[]> r = new ArrayList<>();
                        try (CSVReader reader = new CSVReader(new InputStreamReader(stream))) {
                            try {
                                reader.skip(1);
                                r = reader.readAll();
                                stream.close();
                                reader.close();
                            } catch (CsvException e) {
                                logger.error("Error parsing accounts file {}", e.getMessage());
                            }
                        } catch (IOException e1) {
                            logger.error("Error parsing accounts file {}", e1.getMessage());
                        }
                        logger.info("Rows count {}", r.size());
                        for (String[] arrays : r) {
                            AccountsEntity accountsDetails = new AccountsEntity();
                            accountsDetails.setName(arrays[1]);
                            accountsDetails.setCountry(arrays[2]);
                            accountsDetails.setDomain(arrays[0]);
                            String[] splitStr = new String[50];
                            if (null != arrays[4] && !arrays[4].isEmpty() && arrays[4].contains("_")) {
                                splitStr = arrays[4].split("_");
                                if (arrays[1].isEmpty()) {
                                    accountsDetails.setTagId(StringUtils.EMPTY);
                                } else if (!arrays[1].isEmpty() && splitStr.length == 5) {
                                    accountsDetails.setTagId(StringUtils.containsIgnoreCase(arrays[4], "_Segment_")
                                            ? splitStr[0] + "_" + splitStr[2] + " " + splitStr[3]
                                            : StringUtils.EMPTY);
                                } else {
                                    accountsDetails.setTagId(StringUtils.EMPTY);
                                }
                            } else {
                                accountsDetails.setTagId(StringUtils.EMPTY);
                            }
                            accountsDetails.setFileId(fileId);
                            accountsDetailsList.add(accountsDetails);
                        }
                        logger.info("Accounts count {}", accountsDetailsList.size());
                    }
                    if (StringUtils.containsIgnoreCase(filename, ".tsv")) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
                        try {
                            bufferedReader.readLine();
                        } catch (IOException e) {
                            logger.error("Error reading next line", e.getMessage());
                        } // this will read the first line
                        String line = null;
                        try {
                            while (null != (line = bufferedReader.readLine())) {
                                // split on tab(' ')
                                String[] tsv = line.split("\t");
                                AccountsEntity accountsDetails = new AccountsEntity();
                                accountsDetails.setName(tsv[1]);
                                accountsDetails.setCountry(tsv[2]);
                                accountsDetails.setDomain(tsv[0]);
                                accountsDetails.setTagId("Segment" + StringUtils.substringAfter(tsv[4], "_Segment"));
                                accountsDetails.setFileId(fileId);
                                accountsDetailsList.add(accountsDetails);
                            }
                        } catch (NumberFormatException e) {
                            logger.error("Error converting to number", e.getMessage());
                        } catch (IOException e) {
                            logger.error("Error reading tsv file", e.getMessage());
                        }
                        try {
                            bufferedReader.close();
                        } catch (IOException e) {
                            logger.error("Error closing reader", e.getMessage());
                        }
                    }
                    if (StringUtils.containsIgnoreCase(filename, ".txt")) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
                        try {
                            bufferedReader.readLine();
                        } catch (IOException e) {
                            logger.error("Error reading next line", e.getMessage());
                        } // this will read the first line
                        String line = null;
                        try {
                            while (null != (line = bufferedReader.readLine())) {
                                // split on pipe('|')
                                String[] values = line.split("|");
                                AccountsEntity accountsDetails = new AccountsEntity();
                                accountsDetails.setName(values[1]);
                                accountsDetails.setCountry(values[2]);
                                accountsDetails.setDomain(values[0]);
                                accountsDetails.setTagId(StringUtils.containsIgnoreCase(values[4], "_Segment_")
                                        ? "Segment" + StringUtils.substringAfter(values[4], "_Segment")
                                        : StringUtils.EMPTY);
                                accountsDetails.setFileId(fileId);
                                accountsDetailsList.add(accountsDetails);
                            }
                        } catch (NumberFormatException e) {
                            logger.error("Error converting to number", e.getMessage());
                        } catch (IOException e) {
                            logger.error("Error reading tsv file", e.getMessage());
                        }
                        try {
                            bufferedReader.close();
                        } catch (IOException e) {
                            logger.error("Error closing reader", e.getMessage());
                        }
                    }
                    disconnect();
                    List<FailureAccountsEntity> errorAccountsList = new ArrayList<>();
                    List<AccountsEntity> processingAccountList = new ArrayList<>();
                    Integer errorAccountId = failureRepo.getErrorAccountID();
                    if (accountsDetailsList.size() > 0) {
                        for (AccountsEntity accounts : accountsDetailsList) {
                            if (accounts.getCountry().isEmpty() || accounts.getDomain().isEmpty()
                                    || accounts.getName().isEmpty() || accounts.getTagId().isEmpty()) {
                                FailureAccountsEntity failureAccount = new FailureAccountsEntity();
                                failureAccount.setErrorAccountId(++errorAccountId);
                                failureAccount.setName(accounts.getName());
                                failureAccount.setCountry(accounts.getCountry());
                                failureAccount.setDomain(accounts.getDomain());
                                failureAccount.setMessage("NO DOMAIN/COUNTRY/TAG_ID/ACCOUNT_NAME PROVIDED");
                                failureAccount.setFileId(fileId);

                                errorAccountsList.add(failureAccount);
                            } else if (!accounts.getCountry().isEmpty() && !accounts.getDomain().isEmpty()
                                    && !accounts.getName().isEmpty() && !accounts.getTagId().isEmpty()) {
                                AccountsEntity accountsDetails = new AccountsEntity();
                                accountsDetails.setAccountId(++accountID);
                                accountsDetails.setDomain(accounts.getDomain());
                                accountsDetails.setName(accounts.getName());
                                accountsDetails.setCountry(accounts.getCountry());
                                accountsDetails.setTagId(accounts.getTagId());
                                accountsDetails.setFileId(accounts.getFileId());
                                processingAccountList.add(accountsDetails);
                            }
                        }
                    }
                    logger.info("Error Accounts count {}", errorAccountsList.size());
                    logger.info("Processed Accounts count {}", processingAccountList.size());
                    if (errorAccountsList.size() > 0)
                        failureRepo.insertMultipleErrorAccounts(errorAccountsList);
                    if (processingAccountList.size() > 0) {
                        logger.info("Saving into accounts table");
                        dbSvc.saveAccountsToDb(processingAccountList);
                        matchSegments(date, fileId, processingAccountList);
                    } else {
                        saveFileDetailsWhenEmptyOrInvalidFile(fileId);
                        transferProcessedFileWhenEmpty(fileId);
                    }
                }
            }
        }
    }

    @Override
    public void disconnect() {
        s3Client = null;
    }

    @Override
    public void transfer(String filename) {
        try {
            connect();
            s3Client.copyObject(bucketName, accountsfileLocation + filename, bucketName, processedloc + filename);
            s3Client.deleteObject(bucketName, accountsfileLocation + filename);

        } catch (Exception exception) {
            logger.error("Error connecting to AWS S3 {}", exception.getMessage());
        }
    }


    private void transferProcessedFileWhenEmpty(Integer fileId) {
        Map<String, Object> fileMap = fileRepository.getFileByFileId(fileId);
        transfer(fileMap.get("file_name").toString());
    }

    private void saveFileDetailsWhenEmptyOrInvalidFile(Integer fileId) {
        List<FileEntity> fileList = new ArrayList<>();
        fileList = fileRepository.selectMultipleFiles();
        fileRepository.deleteFiles();
        for (FileEntity file : fileList) {
            if (file.getFileId().equals(fileId.intValue())) {
                file.setProcessEndDateTime(new Date());
                file.setStatus("PROCESS_COMPLETED");
                file.setNoOfAccountsProcessed(0);
            }
        }
        fileList.stream().forEach(file -> fileRepository.insertFile(file));
    }

    public void saveFileInfoToDb(FileEntity fileDetails) {
        logger.info("Saving into File table");
        fileRepository.insertFile(fileDetails);
    }

    public void matchSegments(Date date, Integer fileId, List<AccountsEntity> list) {
        logger.info("Saving Completed to accounts table");
        apiService.matchAccountsWithSegment(date, fileId, list);
    }
}
