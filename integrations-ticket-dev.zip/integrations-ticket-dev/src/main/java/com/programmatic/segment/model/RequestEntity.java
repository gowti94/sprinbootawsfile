package com.programmatic.segment.model;

import java.util.List;

/**
 * @author wajeeha.k
 *
 */
public class RequestEntity {

	private String edited_by;

	private List<AccountsModel> accounts;

	public String getEditedBy() {
		return edited_by;
	}

	public void setEditedBy(String edited_by) {
		this.edited_by = edited_by;
	}

	public List<AccountsModel> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<AccountsModel> accounts) {
		this.accounts = accounts;
	}

	@Override
	public String toString() {
		return "RequestEntity [edited_by=" + edited_by + ", accounts=" + accounts + "]";
	}

}
