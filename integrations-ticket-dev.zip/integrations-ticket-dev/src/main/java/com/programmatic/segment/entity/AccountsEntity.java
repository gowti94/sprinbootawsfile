package com.programmatic.segment.entity;

/**
 * @author wajeeha.k
 *
 */
public class AccountsEntity {

	private Integer accountId;

	private String name;

	private String country;

	private String domain;

	private String tagId;

	private Integer fileId;

	public AccountsEntity() {

	}

	/**
	 * @param accountId
	 * @param name
	 * @param country
	 * @param domain
	 * @param tagId
	 * @param file
	 */
	public AccountsEntity(Integer accountId, String name, String country, String domain, String tagId, Integer fileId) {
		this.accountId = accountId;
		this.name = name;
		this.country = country;
		this.domain = domain;
		this.tagId = tagId;
		this.fileId = fileId;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	@Override
	public String toString() {
		return "AccountsEntity [accountId=" + accountId + ", name=" + name + ", country=" + country + ", domain="
				+ domain + ", tagId=" + tagId + ", fileId=" + fileId + "]";
	}

}
