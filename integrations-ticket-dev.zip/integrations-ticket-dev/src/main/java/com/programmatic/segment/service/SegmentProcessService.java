package com.programmatic.segment.service;

import java.util.Date;
import java.util.List;

import com.programmatic.segment.entity.AccountsEntity;

/**
 * @author wajeeha.k
 *
 */
public interface SegmentProcessService {

	public void matchAccountsWithSegment(Date date, Integer fileId, List<AccountsEntity> list);

}
