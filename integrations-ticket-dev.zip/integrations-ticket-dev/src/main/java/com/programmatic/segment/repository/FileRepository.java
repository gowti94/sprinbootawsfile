package com.programmatic.segment.repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.programmatic.segment.entity.FileEntity;

/**
 * @author wajeeha.k
 *
 */
@Repository
public class FileRepository {

	@Autowired
	@Qualifier("prestoTemplate")
	private JdbcTemplate jdbcTemplate;

	@Value("${segment.database}")
	private String dbName;

	private static final Logger logger = LogManager.getLogger(FileRepository.class);

	public Integer getFileID() {
		String SQL_FILE_ID_SELECT = "SELECT COALESCE(MAX(file_id), 0) as file_id from " + dbName + ".accounts_file";
		Map<String, Object> result = jdbcTemplate.queryForMap(SQL_FILE_ID_SELECT);
		return (Integer) result.get("file_id");
	}

	public void insertFile(FileEntity fileEntity) {
		logger.info("Inserting into accounts_file");
		String SQL_FILE_INSERT_SINGLE = "INSERT INTO " + dbName + ".accounts_file "
				+ "(file_id, file_name, process_start_datetime, process_end_datetime, status, "
				+ "noofrecordsprocessed) VALUES(?, ?, ?, ?, ?, ?)";
		Object[] params = new Object[] { fileEntity.getFileId(), fileEntity.getFileName(),
				fileEntity.getProcessStartDateTime(), fileEntity.getProcessEndDateTime(), fileEntity.getStatus(),
				fileEntity.getNoOfAccountsProcessed() };
		jdbcTemplate.update(SQL_FILE_INSERT_SINGLE, params);
		logger.info("Inserted into accounts_file");
	}

	public Integer getFileIdByFilename(String filename) {
		String SQL_SELECT_FILE = "SELECT * FROM " + dbName + ".accounts_file WHERE file_name = ?";
		Map<String, Object> result = jdbcTemplate.queryForMap(SQL_SELECT_FILE, filename);
		return (Integer) result.get("file_id");
	}

	public Map<String, Object> getFileByFileId(Integer fileId) {
		String SQL_SELECT_FILE = "SELECT * FROM " + dbName + ".accounts_file WHERE file_id = ?";
		Map<String, Object> result = jdbcTemplate.queryForMap(SQL_SELECT_FILE, fileId);
		return result;
	}

	public void deleteFiles() {
		String SQL_DELETE_FILE = "DELETE FROM " + dbName + ".accounts_file";
		jdbcTemplate.execute(SQL_DELETE_FILE);
	}

	public List<FileEntity> selectMultipleFiles() {
		String SQL_SELECT_FILES = "SELECT * FROM " + dbName + ".accounts_file";
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(SQL_SELECT_FILES);
		List<FileEntity> fileList = new ArrayList<>();

		for (Map<String, Object> row : rows) {
			FileEntity file = new FileEntity();
			file.setFileId(Integer.parseInt(String.valueOf(row.get("file_id"))));
			file.setFileName(String.valueOf(row.get("file_name")));
			try {
				file.setProcessStartDateTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S")
						.parse(String.valueOf(row.get("process_start_datetime"))));
			} catch (ParseException e) {
				logger.error("Error parsing date {}", e.getMessage());
			}
			try {
				file.setProcessEndDateTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S")
						.parse(String.valueOf(row.get("process_end_datetime"))));
			} catch (ParseException e) {
				logger.error("Error parsing file {}", e.getMessage());
				e.printStackTrace();
			}
			file.setStatus(String.valueOf(row.get("status")));
			file.setNoOfAccountsProcessed(Integer.parseInt(String.valueOf(row.get("noofrecordsprocessed"))));
			fileList.add(file);
		}

		return fileList;
	}

}
