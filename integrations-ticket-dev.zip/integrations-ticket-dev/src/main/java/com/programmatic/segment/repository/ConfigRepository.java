package com.programmatic.segment.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.programmatic.segment.entity.ConfigEntity;

/**
 * @author wajeeha.k
 *
 */
@Repository
public class ConfigRepository {

	@Autowired
	@Qualifier("prestoTemplate")
	private JdbcTemplate jdbcTemplate;

	@Value("${segment.database}")
	private String dbName;

	private static final Logger logger = LogManager.getLogger(ConfigRepository.class);

	public Integer getConfigID() {
		String SQL_CONFIG_ID_SELECT = "SELECT COALESCE(MAX(config_id), 0) as config_id FROM " + dbName
				+ ".segment_config";
		Map<String, Object> result = jdbcTemplate.queryForMap(SQL_CONFIG_ID_SELECT);
		return (Integer) result.get("config_id");
	}

	public void deleteSegConfig() {
		logger.info("Delete Segment config");
		String SQL_DELETE_SEGMENT_CONFIG = "DELETE FROM " + dbName + ".segment_config";
		jdbcTemplate.execute(SQL_DELETE_SEGMENT_CONFIG);
		logger.info("Deleted Segment config");
	}

	public void deleteConfigStg() {
		logger.info("Delete config_stg");
		String SQL_DELETE_CONFIG_STG = "DELETE FROM " + dbName + ".config_stg";
		jdbcTemplate.execute(SQL_DELETE_CONFIG_STG);
		logger.info("Deleted config_stg");
	}

	public void insertMultipleConfigStg(List<ConfigEntity> configList) {
		String SQL_INSERT_CONFIG_STG = "INSERT INTO " + dbName + ".config_stg " + "(tag_id, segment_id) VALUES(?, ?)"
				+ "";
		deleteConfigStg();
		logger.info("Inserting into config_stg");
		jdbcTemplate.batchUpdate(SQL_INSERT_CONFIG_STG, configList, 100,
				new ParameterizedPreparedStatementSetter<ConfigEntity>() {
					public void setValues(PreparedStatement ps, ConfigEntity configEntity) throws SQLException {
						logger.info("Inserting record {}", configEntity.getConfigId());
						ps.setString(1, configEntity.getTagId());
						ps.setInt(2, configEntity.getSegmentId());
					}
				});
		logger.info("Inserted into config_stg");

	}

	public void insertMultipleSegmentConfig(List<ConfigEntity> configList) {
		String SQL_CONFIG_INSERT_MULTIPLE = "INSERT INTO " + dbName + ".segment_config"
				+ "(config_id, tag_id, segment_id) VALUES(?, ?, ?)" + "";
		logger.info("Inserting into segment_config");
		jdbcTemplate.batchUpdate(SQL_CONFIG_INSERT_MULTIPLE, configList, 100,
				new ParameterizedPreparedStatementSetter<ConfigEntity>() {
					public void setValues(PreparedStatement ps, ConfigEntity configEntity) throws SQLException {
						logger.info("Inserting record {}", configEntity.getConfigId());
						ps.setInt(1, configEntity.getConfigId());
						ps.setString(2, configEntity.getTagId());
						ps.setInt(3, configEntity.getSegmentId());
					}
				});
		logger.info("Inserted into segment_config");
	}
}
