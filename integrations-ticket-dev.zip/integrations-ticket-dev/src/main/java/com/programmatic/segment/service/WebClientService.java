package com.programmatic.segment.service;

import java.util.Date;

/**
 * @author wajeeha.k
 *
 */
public interface WebClientService {

	public Integer pushAccountsToSegment(Date date, int totalNoOfAccounts, Integer fileId, String request,
			Integer segmentId);

}
