package com.programmatic.segment.entity;

/**
 * @author wajeeha.k
 *
 */
public class FailureAccountsEntity {

	private Integer errorAccountId;

	private String name;

	private String country;

	private String domain;

	private String message;

	private Integer fileId;

	public FailureAccountsEntity() {

	}

	/**
	 * @param failedAccountId
	 * @param name
	 * @param country
	 * @param domain
	 * @param message
	 * @param reason
	 * @param fileName
	 */
	public FailureAccountsEntity(Integer errorAccountId, String name, String country, String domain, String message,
			Integer fileId) {
		this.errorAccountId = errorAccountId;
		this.name = name;
		this.country = country;
		this.domain = domain;
		this.message = message;
		this.fileId = fileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public Integer getErrorAccountId() {
		return errorAccountId;
	}

	public void setErrorAccountId(Integer errorAccountId) {
		this.errorAccountId = errorAccountId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	@Override
	public String toString() {
		return "FailureAccountsEntity [errorAccountId=" + errorAccountId + ", name=" + name + ", country=" + country
				+ ", domain=" + domain + ", message=" + message + ", fileId=" + fileId + "]";
	}

}
