package com.programmatic.segment.service;

import java.util.Date;

/**
 * @author Rajkanna.S
 *
 */
public interface AWSS3DownloadService {

	public void connect();

	public void download(Date date);

	public void disconnect();

	public void transfer(String filename);
}
