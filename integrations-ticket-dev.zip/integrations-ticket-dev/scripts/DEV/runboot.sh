#!/bin/bash

java -Xmx3072m -Xms3072m
-DPORT=3004 \
-Dspring.datasource.url="jdbc:presto://presto-tsm.prod1.6si.com:12000/hive" \
-Dspring.datasource.username=hadoop \
-Daccounts.location="sapglobaltest/outgoing/crystal-ball/" \
-Dconfigs.location="sapglobaltest/outgoing/crystal-ball/configs/" \
-Dproccessed.location="sapglobaltest/outgoing/processed/" \
-Ddiagnostic.location="sapglobaltest/outgoing/error/" \
-Dfile.name=SAP-CRYSTALBALL \
-Ds3.region="us-east-1" \
-Ds3.name="6si-sftp-external-test" \
-Dorg.id=4 \
-Dretry.time=3 \
-Dretry.delay=1000 \
-Dretry.multiplier=2 \
-Ddb.name=hive.platformops \
-Dsegment.sense.url="https://aa-api-platform.dev.6si.com" \
-jar segment-1.0.0-SNAPSHOT.jar