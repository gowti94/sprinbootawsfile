#!/bin/bash

java -Xmx3072m -Xms3072m
-DPORT=3004 \
-Dspring.datasource.url="jdbc:presto://presto-tsm.prod1.6si.com:12000/hive" \
-Dspring.datasource.username=hadoop \
-Daccounts.location="sapglobal/outgoing/crystal-ball/" \
-Dconfigs.location="sapglobal/outgoing/crystal-ball/configs/" \
-Dproccessed.location="sapglobal/outgoing/processed/" \
-Ddiagnostic.location="sapglobal/outgoing/error/" \
-Dfile.name=SAP-CRYSTALBALL \
-Ds3.region="us-east-1" \
-Ds3.name="6si-sftp-external" \
-Dorg.id=914 \
-Dretry.time=3 \
-Dretry.delay=1000 \
-Dretry.multiplier=2 \
-Ddb.name=hive.sapglobal \
-Dsegment.sense.url="https://aa-api.prod1.6si.com" \
-jar segment-1.0.0-SNAPSHOT.jar